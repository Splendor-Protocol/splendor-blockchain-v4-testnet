These files examplify how to sign a transaction using the pre-EIP155 scheme. 
